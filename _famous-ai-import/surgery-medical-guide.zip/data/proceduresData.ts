import { ALL_PROCEDURES } from './allProceduresData';

export const PROCEDURES = ALL_PROCEDURES;
